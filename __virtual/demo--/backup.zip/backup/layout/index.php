<?php

$dir_uri = dirname(__FILE__) . '/';
$doc_page_title = '';
$doc_toplevel = true;

require_once( dirname($dir_uri) . '/function.php' );
require_once( dirname(dirname($dir_uri)) . '/common/access.php' );

?>