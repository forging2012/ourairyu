/*1348256612,173213215*/

if (window.CavalryLogger) { CavalryLogger.start_js(["DQmdi"]); }

__d("Nectar",["Env","startsWith"],function(a,b,c,d,e,f){var g=b('Env'),h=b('startsWith');function i(l){if(!l.nctr)l.nctr={};}function j(l){if(g.module||!l)return g.module;var m={fbpage_fan_confirm:true},n;while(l&&l.getAttributeNode){var o=(l.getAttributeNode('id')||{}).value;if(h(o,'pagelet_'))return o;if(n&&m[o])n=o;l=l.parentNode;}return n;}var k={addModuleData:function(l,m){var n=j(m);if(n){i(l);l.nctr._mod=n;}},addImpressionID:function(l){if(g.impid){i(l);l.nctr._impid=g.impid;}}};e.exports=k;});