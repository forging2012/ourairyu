<?php

require_once( './class-file.php' );
$cf = new File();
$r = $cf->traverse(dirname(__FILE__));
$files = array();

function sortbymodified( $a, $b ) {
	return $a['modified'] > $b['modified'] ? -1 : 1;
}
	
foreach( $r['files'] as $file ) {
	$info = $cf->info(iconv(mb_detect_encoding($file), 'UTF-8', dirname(__FILE__).'/'.$file));
	
	if ( $info['privacy'] == 'public' )
		array_push( $files, $info );
}

usort( $files, 'sortbymodified' );

if ( $_SERVER['REQUEST_METHOD'] == "POST" ) {
	header( 'Content-Type: application/json; charset=UTF-8' );
	echo json_encode($files);
}
else { ?>
<!DOCTYPE html> 
<html> 
	<head>
		<base href="http://<?php echo $_SERVER['HTTP_HOST']; ?>/demo/" />
		<meta charset="UTF-8" />
		<meta http-equiv="Content-Language" content="zh-CN" />
		<meta name="viewport" content="width=device-width, initial-scale=1" />
		<meta name="keywords" content="Web-Frontend, HTML, CSS, XML, JavaScript" />
		<meta name="description" content="网站开发技术" />
		<meta name="author" content="Ourai Lam" />
		<meta name="copyright" content="欧雷 版权所有" />
		
		<title>宅男的部屋 &raquo; 演示厅</title>
		
		<link rel="shortcut icon" href="http://ourai.ws/common/images/favicon.ico" />
		
		<link rel="stylesheet" href="http://www.otakism.com/css/reset.css" />
		<link rel="stylesheet" href="http://www.otakism.com/css/global.css" />
		<link rel="stylesheet" href="css/style.css" />
		
		<script src="http://ourai.ws/common/javascript/jquery-1.6.1.min.js"></script>
		<script>
			$( document ).ready(function() {
				$(".file-division-list").each(function() {
					if ( !$(this).children().size() )
						$(this).closest(".file-division").remove();
				});
			});
		</script>
	</head> 
	<body>
		<div id="wrapper">
			<div id="header"><h1>Demos Files</h1></div>
			<div id="content">
			<?php
				echo '<ul class="file-division-list">';
				foreach( $files as $file ) {
					echo '<li class="file-division-item">';
					echo '<a href="' . basename($file['path']) . '" target="_blank" title="在新窗口打开「' . basename($file['path']) . '」文件">' . $file['title'] . '</a>';
					echo '<p>'.$file['description'].'</p>';
					echo '</li>';
				}
				echo '</ul>';
			?>
			</div>
			<div id="footer">Copyright &copy; Ourai Lam</div>
		</div>
	</body>
</html><?php } ?>