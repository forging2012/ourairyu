<?php
/*
	@Title: Class File
	@Description: Process file
	@Privacy: private
*/

class File {

	public function __construct() {
		// 设置默认的时间带
		date_default_timezone_set( 'Etc/GMT-8' );
	}
	
	// 遍历获取指定路径（可以是文件也可以是目录）所在目录下的所有目录及文件
	public function traverse( $path = '' ) {
		$result = array( 'files' => array(), 'dirs' => array() );
		
		if ( is_string( $path ) && is_readable( $path ) ) {
			if ( is_file( $path ) )
				$path = dirname( $path );
				
			if ( $handle = opendir( $path ) ) {
				while( ($file = readdir( $handle )) !== false ) {
					if ( $file == '.' || $file == '..' )
						continue;
						
					if ( is_file( $path . '/' . $file ) ) {
						$fileext = strtolower(pathinfo( $file, PATHINFO_EXTENSION ));
						$filename = pathinfo( $file, PATHINFO_BASENAME );
						$filename = explode( '.', $filename );
						$filename = strtolower($filename[0]);
						
						if ( in_array( $filename, array( 'index', 'default' ) ) && in_array( $fileext, array( 'php', 'html' ) ) || empty( $fileext ) ) {
							continue;
						}
						
						array_push( $result['files'], $file );
					}
					else {
						array_push( $result['dirs'], $file );
					}
				}
				
				clearstatcache();
				closedir( $handle );
			}
		}
		
		return $result;
	}
	
	// 获取文件信息
	public function info( $path = '' ) {
		$result = null;
		
		if ( is_string( $path ) && is_readable( $path ) && is_file( $path ) ) {
			$ext = pathinfo( $path, PATHINFO_EXTENSION );
			
			$result = array(
				'path' => $path,
				'name' => basename( $path, '.' . $ext ),
				'ext' => $ext,
				'size' => filesize( $path ),
				'type' => filetype( $path ),
				'accessed' => date( 'Y-m-d H:i:s', fileatime( $path ) ),
				'modified' => date( 'Y-m-d H:i:s', filemtime( $path ) )
			);
						
			if ( preg_match_all( '/\t@([^\r\n]*)[\n|\r]*/', file_get_contents($path), $match) ) {
				$fileinfo = array('title'=>null, 'privacy'=>null, 'description'=>null);
				
				foreach( $match[1] as $m ) {
					$m = explode( ': ', $m );
					$fileinfo[strtolower($m[0])] = $m[1];
				}
				
				$result = array_merge($result, $fileinfo);
			}
		}
		
		return $result;
	}
	
}

?>